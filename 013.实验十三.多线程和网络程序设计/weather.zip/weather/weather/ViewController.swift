//
//  ViewController.swift
//  weather
//
//  Created by 509 on 2018/12/18.
//  Copyright © 2018年 hdy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var dis: UILabel!
    var weather: String?
    var navTitle: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = navTitle
        dis.text = weather!
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

